import React, { useState } from 'react';

interface WeekdayRangePickerProps {
  onRangeChange: (startDate: Date | null, endDate: Date | null) => void;
}

const WeekdayRangePicker: React.FC<WeekdayRangePickerProps> = ({ onRangeChange }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const isWeekend = (dateString: string): boolean => {
    const date = new Date(dateString);
    const day = date.getDay();
    return day === 0 || day === 6; // 0: Sunday, 6: Saturday
  };

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value && !isWeekend(value)) {
      setStartDate(value);
      onRangeChange(new Date(value), endDate ? new Date(endDate) : null);
    } else {
      alert('Weekends are not allowed. Please select a weekday.');
    }
  };

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value && !isWeekend(value)) {
      setEndDate(value);
      onRangeChange(startDate ? new Date(startDate) : null, new Date(value));
    } else {
      alert('Weekends are not allowed. Please select a weekday.');
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      <div>
        <label htmlFor="startDate">Start Date:</label>
        <input
          type="date"
          id="startDate"
          value={startDate}
          onChange={handleStartDateChange}
        />
      </div>
      <div>
        <label htmlFor="endDate">End Date:</label>
        <input
          type="date"
          id="endDate"
          value={endDate}
          onChange={handleEndDateChange}
        />
      </div>
    </div>
  );
};

export default WeekdayRangePicker;
