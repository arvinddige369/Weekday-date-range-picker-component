import React, { Component } from 'react';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render shows the fallback UI
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    console.error('Error in component:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // Render a more informative error message
      return (
        <div>
          <h1>Something went wrong.</h1>
          <p>
            An error occurred in the application. 
            Please try refreshing the page or contacting support.
          </p>
          <p>Error Details:</p>
          <pre>{this.state.error.toString()}</pre> 
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;