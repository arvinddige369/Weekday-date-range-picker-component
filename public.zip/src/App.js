import React from 'react';
// import ErrorBoundary from './component/ErrorBoundary';
import WeekdayRangePicker from './component/WeekdayRangePicker';

const App: React.FC = () => {
  const handleRangeChange = (startDate: Date | null, endDate: Date | null) => {
    console.log('Selected Range:', startDate, endDate);
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Weekday Range Picker</h1>
      <WeekdayRangePicker onRangeChange={handleRangeChange} />
    </div>
  );
};

export default App;